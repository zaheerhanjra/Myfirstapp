document.addEventListener('DOMContentLoaded', () => {
    const movies = [
        { title: "Inception", image: "https://via.placeholder.com/200x300?text=Inception" },
        { title: "The Dark Knight", image: "https://via.placeholder.com/200x300?text=The+Dark+Knight" },
        { title: "Interstellar", image: "https://via.placeholder.com/200x300?text=Interstellar" },
        { title: "Avengers", image: "https://via.placeholder.com/200x300?text=Avengers" }
    ];

    const movieList = document.getElementById('movie-list');

    movies.forEach(movie => {
        const movieDiv = document.createElement('div');
        movieDiv.className = 'movie';
        movieDiv.innerHTML = `
            <img src="${movie.image}" alt="${movie.title}">
            <h3>${movie.title}</h3>
        `;
        movieList.appendChild(movieDiv);
    });
});
